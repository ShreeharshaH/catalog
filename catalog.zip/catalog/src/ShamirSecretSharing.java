import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class ShamirSecretSharing {

    // Method to decode the y-values based on the base
    public static List<int[]> decodeValues(JSONObject data) {
        List<int[]> decodedPoints = new ArrayList<>();

        // Loop through each key (ignoring the "keys" object)
        for (String key : data.keySet()) {
            if (key.matches("\\d+")) { // Ensure we're dealing with keys like "1", "2", etc.
                JSONObject point = data.getJSONObject(key);

                // Get the base and value
                int base = point.getInt("base");
                String value = point.getString("value");

                // Convert the value from the given base to decimal
                int decodedY = Integer.parseInt(value, base);

                // Collect the decoded (x, y) pair as int[] {x, y}
                decodedPoints.add(new int[]{Integer.parseInt(key), decodedY});
            }
        }

        return decodedPoints;
    }

    // Lagrange interpolation method to find the constant term 'c'
    public static double lagrangeInterpolation(List<int[]> points) {
        double c = 0; // constant term we need to calculate

        // Loop through each point and apply Lagrange interpolation
        for (int i = 0; i < points.size(); i++) {
            int xi = points.get(i)[0];
            int yi = points.get(i)[1];

            // Calculate the Lagrange basis polynomial for this point
            double li = 1;
            for (int j = 0; j < points.size(); j++) {
                if (i != j) {
                    int xj = points.get(j)[0];
                    li *= (0.0 - xj) / (xi - xj); // Polynomial evaluated at x = 0
                }
            }

            // Add the term yi * li to the result
            c += yi * li;
        }

        return c;
    }

    public static void main(String[] args) {
        // Sample JSON input
        String jsonString = "{\n" +
                "    \"keys\": {\n" +
                "        \"n\": 4,\n" +
                "        \"k\": 3\n" +
                "    },\n" +
                "    \"1\": {\n" +
                "        \"base\": \"10\",\n" +
                "        \"value\": \"4\"\n" +
                "    },\n" +
                "    \"2\": {\n" +
                "        \"base\": \"2\",\n" +
                "        \"value\": \"111\"\n" +
                "    },\n" +
                "    \"3\": {\n" +
                "        \"base\": \"10\",\n" +
                "        \"value\": \"12\"\n" +
                "    },\n" +
                "    \"6\": {\n" +
                "        \"base\": \"4\",\n" +
                "        \"value\": \"213\"\n" +
                "    }\n" +
                "}";

        // Parse the JSON string
        JSONObject data = new JSONObject(jsonString);

        // Decode the (x, y) values
        List<int[]> decodedPoints = decodeValues(data);

        // Calculate the constant term 'c' using Lagrange interpolation
        double constantTerm = lagrangeInterpolation(decodedPoints);

        // Print the result
        System.out.println("The constant term c is: " + constantTerm);
    }
}
